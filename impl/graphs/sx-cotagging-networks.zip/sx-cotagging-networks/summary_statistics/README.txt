Basic dataset statistics.

head -5 dataset_stats.csv
-------
$ ,exchange,num_post,num_tag,unique_tag
0,3dprinting.txt,1639.0,230.0,230.0
1,german.txt,10663.0,258.0,258.0
2,joomla.txt,5567.0,331.0,331.0
3,softwareengineering.txt,49819.0,1646.0,1646.0
-------

Colunn information:
1. row ID
2. name of Stack Exchange community
3. number of posts
4. number of times a tag has been applied to a question
5. number of unique tags
